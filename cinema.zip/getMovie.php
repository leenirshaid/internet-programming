<?php

include "connection.php";
$title=$_GET['txtMovie'];

$sql="SELECT title from movie where title=".$title;
$result=$con->query($sql);
$ok=0;
if($result->num_rows==0){

   $ok=1;
}
else{

}
echo json_encode($ok);

$con->close();