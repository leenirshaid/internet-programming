

<?php

include 'connection.php';

    $srch_title = $_GET['title'];
    $success = 0;

    $sql = "SELECT title from movie where title='$srch_title'";
    $result = $con->query($sql);

    if ($result->num_rows > 0) {
        $success=1;
    } else {

    }


 echo json_encode($success);

$con->close();
?>
