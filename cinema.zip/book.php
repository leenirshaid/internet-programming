
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BOOKING</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        html {
            background: url("bookbg.jpg") no-repeat center center fixed;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
        }
        .jumbotron{

            background-color: rgba(32, 32, 32, 0.59);
        }
        body{
            background-color: rgba(0, 0, 0, 0);
        }
        label{
            color: #ffffff
        }
        .header{
            color: rgba(255, 255, 255, 0.64)
        }
        li{
            font-size: 18px;
        }
        #btn1{
            width:50px;
            height:34px;
            background-color: rgba(26,26,26,0.77);
            color:white;
        }
        #srch-term{
            background-color: rgba(194, 194, 194, 0.26);
            border-color: rgba(194,194,194,0.26);
            color: white;
        }

    </style>
    <script>
        function ajax() {
            var title=document.getElementById("srch-term").value;
            var arr=title.split(" ");
            var newtitle="";
            for(var i=0;i<arr.length;i++){
                newtitle+=arr[i];
            }


            $.ajax({
                type: "GET",
                url: "http://localhost/final/search.php?title=" + $("#srch-term").val(),
                dataType: "json",
                cache: false,

                success: function (data) {

                    // alert(data);
                    if (data =="1") {
                        // alert("hi");
                        window.location.replace("http://localhost/final/"+newtitle+".html");
                    }
                    else {
                        window.location.replace("http://localhost/final/nowshowing.html");
                    }
                },

                error: function (error) {
                    alert(error);
                }


            })




        }
    </script>
</head>
<body>
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="home.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span></a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="nowshowing.html">Now Showing</a></li>
            <li><a href="comingsoon.html">Coming Soon</a></li>
            <li class="active"><a href="book.php">Book Your Ticket</a></li>
            <li><a href="contact.html">Contact us</a></li>
            <li> <div class="col-md-12">
                    <form class="navbar-form" role="search">
                        <div class="input-group add-on">
                            <input class="form-control" placeholder="Search" name="title" id="srch-term" type="text">
                            <div class="input-group-btn">
                                <button class="btn" id="btn1" onclick="ajax()"><i class="glyphicon glyphicon-search"></i></button>
                            </div>
                        </div>
                    </form></div></li>

        </ul>
    </div>
</nav>
<div class="container-fluid">
    <div class="jumbotron">
        <div class="header">
            <h1 align="center">Book Your Ticket</h1>
        </div>
        <br><br>
        <form class="form-horizontal" method="get" action="insertCust.php">
            <div class="form-group">
                <label for="name" class="col-sm-4 control-label">Name: </label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" name="txtName" id="name">
                </div>
            </div>
            <div class="form-group">
                <label for="phone" class="col-sm-4 control-label">Phone: </label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" name="txtPhone" id="phone">
                </div>
            </div>

            <div class="form-group">
                <label for="movie" class="col-sm-4 control-label">Movie: </label>
                <div class="col-sm-4" >
                    <select id="movie" name="txtMovie" class="form-control">

                        <option selected>Select one</option>

                        <?php
                        include "connection.php";
                        $sql="SELECT title from movie";
                        $result=$con->query($sql);

                        if($result->num_rows>0){
                        while($row=$result->fetch_assoc()){
                        echo ("<option>".$row["title"]."</option>");
                             }
                        }
                        else {
                            echo "0 results";
                        }
                        ?>

                    </select>
                    <div id="d"></div>
                </div>
            </div>
            <div class="form-group">
                <label for="no" class="col-sm-4 control-label">Date: </label>
                <div class="col-sm-4">
                    <input type="date" class="form-control" name="txtDate" id="date" max="2017-09-30" min="2017-09-01">
                </div>
            </div>
            <div class="form-group">
                <label for="time" class="col-sm-4 control-label">Time: </label>
                <div class="col-sm-4">
                    <select id="time" name="txtTime" class="form-control">
                        <option selected>Any time</option>
                        <option>Before 5pm</option>
                        <option>After 5pm</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="no" class="col-sm-4 control-label">Tickets No.: </label>
                <div class="col-sm-4">
                    <input type="number" class="form-control" name="txtNo" id="no" min="1" max="20" value="1">
                </div>
            </div>
            <div class="form-group">
                <label for="no" class="col-sm-5 control-label"></label>
                <div class="col-sm-2">
                    <input type="submit" class="form-control"  id="btn" value="book ticket">
                </div>
            </div>

        </form>
    </div>
</div>

</body>
</html>


