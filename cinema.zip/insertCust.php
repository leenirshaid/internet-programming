<?php

include "connection.php";

$name=$_GET['txtName'];
$phone=$_GET['txtPhone'];
$movie=$_GET['txtMovie'];
$date=$_GET['txtDate'];
$time=$_GET['txtTime'];
$noOfTickets=$_GET['txtNo'];
$ok=0;
$sql="INSERT into customer(name,phone,movie,date,time,noOfTickets) values ('$name',$phone,'$movie','$date','$time',$noOfTickets);";

if($con->query($sql)===true) {
  header("location: /final/home.html");
}
else{

   echo($con->error);
}
//echo json_encode($ok);
$con->close();