<?php
include "connection.php";
//execute sql
$sql="SELECT title from movie";
$result=$con->query($sql);

if($result->num_rows>0){
    while($row=$result->fetch_assoc()){
        echo $row["title"]." ";
    }
}
else {
    echo "0 results";
}
